﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR15_16
{
    class Student
    {
        private string FIO;
        private int number;
        private int algebra;
        private int english;
        private int chemistry;
        private int geography;
        private int history;
        public Student()
        {
            FIO = "Ivaniv I.I";
            number = 4;
            algebra = 4;
            english = 5;
            chemistry = 3;
            geography = 5;
            history = 5;
        }
        public Student(string f, int num, int a, int eng, int che, int geo, int his)
        {
            FIO = f;
            number = num;
            algebra = a;
            english = eng;
            chemistry = che;
            geography = geo;
            history = his;
        }
        public void InputFromFile(StreamReader sr)
        {
            string input = sr.ReadLine();
            string[] info = input.Split(';');
            FIO = info[0];
            number = int.Parse(info[1]);
            algebra = int.Parse(info[2]);
            english = int.Parse(info[3]);
            chemistry = int.Parse(info[4]);
            geography = int.Parse(info[5]);
            history = int.Parse(info[6]);

        }
        public string Output()
        {
            return $"Студент {FIO}; " +
                $"группа номер {number}; " +
                $"Оценка по алгебре {algebra}; " +
                $"Оценка по английскому {english}; " +
                $"Оценка по химии {chemistry}; " +
                $"Оценка по географии {geography}; " +
                $"Оценка по истории {history}; ";
        }
        public void Save()
        {
            StreamWriter sr = new StreamWriter(@"Result.txt", true);
            sr.WriteLine($"{FIO};{number};{algebra};{english};{chemistry};{geography};{history}");
            sr.Close();
        }
        public int Average()
        {
            return (algebra + english + chemistry + geography + history) / 5;
        }
    }
}